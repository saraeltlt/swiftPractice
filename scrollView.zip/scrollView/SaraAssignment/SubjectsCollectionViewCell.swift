//
//  SubjectsCollectionViewCell.swift
//  teacher screen
//
//  Created by Sara El-Tlt on 11/1/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//

import UIKit

class SubjectsCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var SubjectLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
