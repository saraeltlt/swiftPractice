//
//  TeacherDetailsViewController.swift
//  SaraAssignment
//
//  Created by Bassant Khaled on 11/1/20.
//  Copyright © 2020 Ibtikar. All rights reserved.
//

import UIKit

class TeacherDetailsViewController: UIViewController {

    @IBOutlet weak var image: UIImageView!
    
    @IBOutlet weak var ReviewsTableView: UITableView!
    
    @IBOutlet var subjectsCollectionView: UICollectionView!
    
    let UserSArray =
    [
        ["name": "Ahmed", "Rate": "3", "image": UIImage(imageLiteralResourceName: "ic_male_inactive"), "review": "Teacher is perfect."],
         ["name": "Mostafa", "Rate": "3", "image": UIImage(imageLiteralResourceName: "ic_male_inactive"), "review": "Teacher is really good and nice."],
         ["name": "khaled", "Rate": "1", "image": UIImage(imageLiteralResourceName: "ic_male_inactive"), "review": "i didn't like him."]
         
     ]
    
    
    let subjectsArray = ["Mathmatics", "Arabic", "English"]
    
    //***********
    override var preferredStatusBarStyle: UIStatusBarStyle {
              return .lightContent
          }
    override func viewDidLoad() {
        super.viewDidLoad()
        //****
         setNeedsStatusBarAppearanceUpdate()
     
         navigationController?.navigationBar.backIndicatorImage = UIImage(imageLiteralResourceName: "left")
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(imageLiteralResourceName: "left")
        //***********
           self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        
        subjectsCollectionView.register(SubjectsCollectionViewCell.self, forCellWithReuseIdentifier: "SubjectsCollectionViewCell")
        
    
        
        ReviewsTableView.register(UINib(nibName: "ReviewsTableViewCell", bundle: nil), forCellReuseIdentifier: "ReviewsTableViewCell")
     
      image?.layer.borderWidth = 5
         image?.layer.masksToBounds = false
         image?.layer.borderColor = UIColor.white.cgColor
         image?.layer.cornerRadius = image.frame.height/2
         image?.clipsToBounds = true
        
        
       
        
        
        
        
        
    }


}
extension TeacherDetailsViewController : UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
}
extension TeacherDetailsViewController : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return UserSArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ReviewsTableViewCell") as? ReviewsTableViewCell
       if let item = UserSArray[indexPath.row] as? [String: Any] {
         let name = item["name"] as? String
          let rate = item["Rate"] as? String
         let  review = item["review"] as? String
      let image = item["image"] as? UIImage
        
        cell?.UserName.text = name
        cell?.UserRate.text = rate
            cell?.UserReview.text = review
            cell?.UserImage.image = image
        }
        return cell!
    }
    
    
}

extension TeacherDetailsViewController : UICollectionViewDelegate {
    
}
extension TeacherDetailsViewController : UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return subjectsArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let subjectCell = collectionView.dequeueReusableCell(withReuseIdentifier: "SubjectsCollectionViewCell", for: indexPath) as? SubjectsCollectionViewCell
        //subjectCell?.SubjectLabel.text = subjectsArray[indexPath.row]
        return  subjectCell!
    }
    
    
}
