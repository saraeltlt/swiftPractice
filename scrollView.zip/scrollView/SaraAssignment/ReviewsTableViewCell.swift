//
//  ReviewsTableViewCell.swift
//  teacher screen
//
//  Created by Sara El-Tlt on 11/1/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//

import UIKit

class ReviewsTableViewCell: UITableViewCell {

    @IBOutlet weak var UserImage: UIImageView!
    @IBOutlet weak var UserName: UILabel!
    @IBOutlet weak var UserReview: UILabel!
    @IBOutlet weak var UserRate: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
