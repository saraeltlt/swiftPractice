//
//  ContactModel.swift
//  vivooo
//
//  Created by Sara El-Tlt on 10/14/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//
import Foundation

struct Contact {
    let name: String?
    let phoneNo: String?
}
