//
//  contactViewController.swift
//  vivooo
//
//  Created by Sara El-Tlt on 10/6/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//

import UIKit

class contactViewController: UIViewController {

    @IBOutlet weak var cotactTableView: UITableView!
  
    var sectionArray = [ContactSection]()
    
    
    var recentContactDictionaryArray = [Contact] ()
    //[
     //  ["name": "passant", "phone": "1234"],
      //  ["name": "eman", "phone": "5678"]
    //]
    
  var allContactDictionaryArray = [Contact] ()
   // [
    //    ["name": "sara", "phone": "91011"],
    //    ["name": "nour", "phone": "121314"],
     //   ["name": "ghada", "phone": "151617"],  ["name": "loay", "phone": "181920"]
    //]
    
    //2
      var getContactDelegate : getContactData?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        cotactTableView.register(UINib(nibName: "contactTableViewCell", bundle: nil ), forCellReuseIdentifier: "contactTableViewCell")
        
        

         let sara = Contact(name: "sarasarasarasarasarasarasarasarasarasarasarasara sara", phoneNo: "01206425318")
         self.recentContactDictionaryArray.append(sara)
        let passant = Contact(name: "passant", phoneNo: "01090902020p")
         self.recentContactDictionaryArray.append(passant)
         
         let mohamed = Contact(name: "mohamed", phoneNo: "0111092089")
          let ahmed = Contact(name: "ahmed", phoneNo: "84534958")
         let mahmoud = Contact(name: "mahmoud", phoneNo: "22392858")
         
         self.allContactDictionaryArray = [mohamed,ahmed,mahmoud]
        
        //creat 2 section Object
        let recentObjectSection = ContactSection(sectionName: "recent", sectionItems: recentContactDictionaryArray)
        let allObjectSection = ContactSection(sectionName: "all", sectionItems: allContactDictionaryArray)
        
        //append section in array
        sectionArray.append(recentObjectSection)
        sectionArray.append(allObjectSection)
        
    }
    
    
   

}

extension contactViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return self.sectionArray[section].sectionName
    }
  
 
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
}

extension contactViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return sectionArray.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let sectionItem = self.sectionArray[section]  // get sections
        let sectionItemsData = sectionItem.sectionItems //get Items inside section object
        return sectionItemsData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "contactTableViewCell") as?  contactTableViewCell
        
        let itemSection = self.sectionArray[indexPath.section]
        let itemSectionData = itemSection.sectionItems
     let itemSectionDataObject = itemSectionData[indexPath.row]
        let name = itemSectionDataObject.name
        let number =  itemSectionDataObject.phoneNo
            
            cell?.nameLableView.text = name
            cell?.NumberLableView.text = number
     

        return cell!
    }
    //3
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let selectedObject = self.sectionArray[indexPath.section].sectionItems[indexPath.row]
        self.getContactDelegate?.getContactDetails(contactObject: selectedObject)
        self.navigationController?.popViewController(animated: true)
        
    }
    
}
