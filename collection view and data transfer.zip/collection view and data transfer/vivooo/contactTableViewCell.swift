//
//  contactTableViewCell.swift
//  vivooo
//
//  Created by Sara El-Tlt on 10/6/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//

import UIKit

class contactTableViewCell: UITableViewCell {
    @IBOutlet weak var NumberLableView: UILabel!
    @IBOutlet weak var nameLableView: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
