//
//  chooseContactViewController.swift
//  vivooo
//
//  Created by Sara El-Tlt on 10/14/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//

import UIKit
protocol getContactData {
    func getContactDetails(contactObject: Contact)
}

class chooseContactViewController: UIViewController {

    @IBOutlet weak var contactPhoneNumLabel: UILabel!
    @IBOutlet weak var contactNameLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    
    @IBAction func chooseContactButton(_ sender: Any) {
        
        
        
        self.performSegue(withIdentifier: "goToChooseContacts", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToChooseContacts" {
            if let dest = segue.destination as? contactViewController {
                dest.getContactDelegate = self
            }
        }
    }
    

}
extension chooseContactViewController : getContactData{
    func getContactDetails(contactObject: Contact) {
        if let name = contactObject.name
        {
            self.contactNameLabel.text = name
            
        }
        if let phone = contactObject.phoneNo {
            self.contactPhoneNumLabel.text = phone
        }
        
    }
    
    
}
