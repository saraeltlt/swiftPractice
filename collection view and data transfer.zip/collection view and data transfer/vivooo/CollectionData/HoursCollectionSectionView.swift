//
//  HoursCollectionSectionView.swift
//  vivooo
//
//  Created by Sara El-Tlt on 10/19/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//

import UIKit

class HoursCollectionSectionView: UICollectionReusableView {

    @IBOutlet weak var sectionLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
