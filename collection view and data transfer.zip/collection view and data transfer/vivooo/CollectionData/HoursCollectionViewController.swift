//
//  HoursCollectionViewController.swift
//  vivooo
//
//  Created by Sara El-Tlt on 10/15/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//

import UIKit

class HoursCollectionViewController: UIViewController {
    @IBOutlet weak var HoursCollectionView: UICollectionView!
    
    // var hoursArr = ["12:00 PM",
    //                "1:00 PM",
    //               "2:00 PM",
    //               "3:00 PM",
    //              "4:00 PM",
    //              "5:00 PM",
    //             "6:00 PM",
    //             "7:00 PM",
    //            "8:00 PM",
    //             "9:00 PM",
    //            "10:00 PM",
    //         "11:00 PM",
    //            "12:00 AM",
    //         "1:00 AM",
    //           "2:00 AM",
    //           "3:00 AM",
    //           "4:00 AM",
    //          "5:00 AM",
    //          "6:00 AM",
    //         "7:00 AM",
    //        "8:00 AM",
    //        "9:00 AM",
    //        "10:00 AM",
    //       "11:00 AM",
    
    //]
    
    var sectionArray = [ContactSection]()
    
    var recentContactDictionaryArray = [Contact] ()
    var allContactDictionaryArray = [Contact] ()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.HoursCollectionView.register(UINib(nibName: "HoursCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "HoursCollectionViewCell")
        self.HoursCollectionView.register(UINib(nibName: "HoursCollectionSectionView", bundle: nil), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "HoursCollectionSectionView")
        
        
        
        
        let sara = Contact(name: "sara", phoneNo: "01206425318")
        self.recentContactDictionaryArray.append(sara)
        let pasant = Contact(name: "pasant", phoneNo: "01090902020p")
        self.recentContactDictionaryArray.append(pasant)
        let menna = Contact(name: "menna", phoneNo: "652832938")
          self.recentContactDictionaryArray.append(menna)
        
        let mai = Contact(name: "mai", phoneNo: "0111092089")
        let ahmed = Contact(name: "ahmed", phoneNo: "84534958")
        let ali = Contact(name: "Ali", phoneNo: "22392858")
        
        
        self.allContactDictionaryArray = [mai,ahmed,ali]
        
        //creat 2 section Object
        let recentObjectSection = ContactSection(sectionName: "recent", sectionItems: recentContactDictionaryArray)
        let allObjectSection = ContactSection(sectionName: "all", sectionItems: allContactDictionaryArray)
        
        //append section in array
        sectionArray.append(recentObjectSection)
        sectionArray.append(allObjectSection)
    }
    
    
    
    
}
extension HoursCollectionViewController: UICollectionViewDelegate {
    
}


extension HoursCollectionViewController: UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return sectionArray.count
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return sectionArray[section].sectionItems.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let hoursCell = collectionView.dequeueReusableCell(withReuseIdentifier: "HoursCollectionViewCell", for: indexPath) as? HoursCollectionViewCell
       // hoursCell?.hourLabel.text = hoursArr[indexPath.row]
        hoursCell?.hourLabel.text = self.sectionArray[indexPath.section].sectionItems[indexPath.row].name
        
        return hoursCell!
    }
    
    
}

extension HoursCollectionViewController : UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize (width: self.view.frame.width/2-50, height: 100)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        switch kind {
        case UICollectionView.elementKindSectionHeader:
            let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "HoursCollectionSectionView", for: indexPath) as? HoursCollectionSectionView
            headerView?.sectionLabel.text = self.sectionArray[indexPath.section].sectionName
            return headerView!
            
        case UICollectionView.elementKindSectionFooter:
            return UICollectionReusableView()
        
        default:
             return UICollectionReusableView()
        }
    
}
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: self.view.frame.width, height: 45)
    }
}
