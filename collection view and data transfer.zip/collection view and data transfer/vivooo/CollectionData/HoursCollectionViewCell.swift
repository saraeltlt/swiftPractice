//
//  HoursCollectionViewCell.swift
//  vivooo
//
//  Created by Sara El-Tlt on 10/15/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//

import UIKit

class HoursCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var hourLabel: UILabel!
    
    @IBOutlet weak var hourRoundedView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        hourRoundedView.layer.cornerRadius = 40
       hourRoundedView.layer.masksToBounds = true
        
    }

}
