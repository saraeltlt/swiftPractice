//
//  ContentView.swift
//  vivooo
//
//  Created by Sara El-Tlt on 9/28/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//

import UIKit
import SwiftUI

class ContentView: View {
    v
    

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
