//
//  RowTableViewCell.swift
//  vivooo
//
//  Created by Sara El-Tlt on 9/29/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//

import UIKit

class RowTableViewCell: UITableViewCell {

    @IBOutlet weak var number: UILabel!

   
    @IBOutlet weak var rowLable: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
