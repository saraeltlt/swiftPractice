//
//  ShowRowDetailsViewController.swift
//  vivooo
//
//  Created by Sara El-Tlt on 10/1/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//

import UIKit

class ShowRowDetailsViewController: UIViewController {


    @IBOutlet weak var showDetailsApp: UILabel!
    
   var rowName = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        self.showDetailsApp.text = rowName
        
 
    }
    



}
