//
//  SignUpViewController.swift
//  vivooo
//
//  Created by Sara El-Tlt on 9/15/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
   let backgroundImageView = UIImageView()
    override func viewDidLoad() {
        super.viewDidLoad()
      setBackground()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
              if segue.identifier == "signupToWelcome" {
                  if let welcViewController = segue.destination as? WelcomeViewController {
                      if let email = sender as? String{
                       welcViewController.nameValue = email
                      }
                  }
              }
          }
   
    override func viewDidDisappear(_ animated: Bool) {
    nameTextField.text=""
    emailTextField.text=""
    passwordTextField.text=""
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
     
     
    }
    */
    @IBAction func signUpBotton(_ sender: Any) {
        if let name=nameTextField.text,
            let email=emailTextField.text,
            let password=passwordTextField.text,
            !name.isEmpty, !email.isEmpty , !password.isEmpty {
            
             self.performSegue(withIdentifier: "signupToWelcome", sender: name)
       // let storyBoard = UIStoryboard(name: "Main", bundle: nil)
         //et welcomeViewController = storyBoard.instantiateViewController(identifier: "welcomeViewController") as? WelcomeViewController
           // if let mainNavi = self.navigationController ,
                 //        let welcome = welcomeViewController
                  //  {

                     // welcome.nameValue = name
                   //mainNavi.pushViewController(welcome, animated: true)
                      // }
        }
    }
    func setBackground () {
        view.addSubview(backgroundImageView)
        backgroundImageView.translatesAutoresizingMaskIntoConstraints = false
        backgroundImageView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        backgroundImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
         backgroundImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
         backgroundImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        backgroundImageView.image = UIImage(named: "backgroundMarble")
         view.sendSubviewToBack(backgroundImageView)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       self.navigationController!.navigationBar.barStyle = .black
      }
}
