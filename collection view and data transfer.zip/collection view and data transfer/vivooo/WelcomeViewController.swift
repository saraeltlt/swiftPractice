//
//  WelcomeViewController.swift
//  vivooo
//
//  Created by Sara El-Tlt on 9/24/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//

import UIKit

class WelcomeViewController: UIViewController {
       @IBOutlet weak var nameLable: UILabel!
    var nameValue = ""
     let backgroundImageView = UIImageView()
    override func viewDidLoad() {
           setBackground()
        super.viewDidLoad()
        self.nameLable.text=nameValue

      
    }
    func setBackground () {
               view.addSubview(backgroundImageView)
               backgroundImageView.translatesAutoresizingMaskIntoConstraints = false
               backgroundImageView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
               backgroundImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
                backgroundImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
                backgroundImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
               backgroundImageView.image = UIImage(named: "backgroundMarble")
           view.sendSubviewToBack(backgroundImageView)
           }
    
 override func viewWillAppear(_ animated: Bool) {
     super.viewWillAppear(animated)
    self.navigationController!.navigationBar.barStyle = .black
   }
 

    

}
