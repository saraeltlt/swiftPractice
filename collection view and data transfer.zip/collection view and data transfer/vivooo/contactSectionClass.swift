//
//  contactSectionClass.swift
//  vivooo
//
//  Created by Sara El-Tlt on 10/6/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//

import Foundation
struct ContactSection{
    let sectionName : String
    let sectionItems: [Contact]
}
