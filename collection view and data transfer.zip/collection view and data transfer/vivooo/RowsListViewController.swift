//
//  RowsListViewController.swift
//  vivooo
//
//  Created by Sara El-Tlt on 9/29/20.
//  Copyright © 2020 Sara El-Tlt. All rights reserved.
//

import UIKit

class RowsListViewController: UIViewController {

    @IBOutlet weak var rowListTableView: UITableView!
    var nameArray = ["passant","sara", "omnia", "nour" , "ahmed", "mohamed"]
   
    override func viewDidLoad() {
        super.viewDidLoad()
         let rowsCell =  UINib (nibName: "RowTableViewCell", bundle: nil)
        self.rowListTableView.register(rowsCell, forCellReuseIdentifier: "RowTableViewCell")
      
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToD" {
            if let detailViewController = segue.destination as? ShowRowDetailsViewController  {
                if let selectedIndexPath = sender as? IndexPath {
                    let selectedNameFromArray = self.nameArray[selectedIndexPath.row]
                    detailViewController.rowName = selectedNameFromArray
                 
                }
            }
        }
    }
    }



extension RowsListViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70.0
    }
    
}
extension RowsListViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nameArray.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "RowTableViewCell") as?  RowTableViewCell

      cell?.number.text = "\(indexPath.row))"
        
        cell?.rowLable.text = self.nameArray[indexPath.row]
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("selected row: \(indexPath.row)")
        //
        //        let selectedName = self.namesArray[indexPath.row]
        //
        //        print(selectedName)
        //
        //        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        //        let detailsViewController = storyBoard.instantiateViewController(withIdentifier: "ShowRowDetailsViewController") as? ShowRowDetailsViewController
        //
        //        detailsViewController?.rowName = selectedName
        //
        //
        //        self.navigationController?.pushViewController(detailsViewController!, animated: true)
                
                self.performSegue(withIdentifier: "goToD", sender: indexPath)
    }
    
     
}


